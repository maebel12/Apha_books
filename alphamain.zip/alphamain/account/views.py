from django.shortcuts import render, redirect
from .forms import SIGNUPFORM, LOGINFORM
from django.contrib.auth import authenticate, login
def index(request):
    return render()
def register(request):
    nsg = None
    if request.method == 'post':
        form= SIGNUPFORM(request.post)
        if form.is_valid(request.POST):
            user = form.save()
            nsg = 'user created'
            return redirect('login_view')
        else:
             nsgv = 'form not valid'
    else:
        form = SIGNUPFORM()
    return render(request, 'register',{'form': form, 'nsg': nsg})
def login_view(request):
    form = LOGINFORM(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                nsg = 'invaild credentials'
        else:
            nsg = 'error validation'
    return render(request, 'login', {'form': form, 'nsg': nsg})
def admin(request):
    return render(request, 'home')
def customer(request):
    return render(request, 'home')
def publisher(request):
    return render(request, 'home')
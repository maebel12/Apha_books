from django.contrib.auth import UserCreationForm
from django import forms
from .models import User

class LOGINFORM(forms.Form):
    username = forms.CharField(
        widget= forms.TextField(
            attrs={

            }
        )
    )
    password = forms.CharField(
        widget= forms.PasswordInput(
            attrs={
                
            }
        )
    )

class SIGNUPFORM(forms.Form):
    username = forms.CharField(
        widget= forms.TextField(
            attrs={

            }
        )
    )
    email = forms.CharField(
        widget= forms.TextField(
            attrs={

            }
        )
    )
    password = forms.CharField(
        widget= forms.PasswordInput(
            attrs={
                
            }
        )
    )

class Meta:
    model = User 
    fields = ('user', 'email', 'password', 'password2', 'is_admin', 'is_customer', 'is_publisher')
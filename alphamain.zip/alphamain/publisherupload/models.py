from django.db import models

# Create your models here.
class FileType(models.Model):
    name=models.CharField(max_length=255) 
    def __str__(self) -> str:
        return self.name

class Author(models.Model):
    name=models.CharField(max_length=500)
    def __str__(self) -> str:
        return self.name
class Publisher(models.Model):
    name=models.CharField(max_length=500)
    def __str__(self) -> str:
        return self.name
class Typecatagory(models.Model):
    name=models.CharField(max_length=500)
    def __str__(self) -> str:
        return self.name

class Book(models.Model):
    title=models.CharField(max_length=500, null=True)
    author=models.ForeignKey(Author,on_delete= models.PROTECT,null=True)
    price=models.IntegerField(null=True)
    filetype=models.ForeignKey(FileType, on_delete= models.PROTECT,null=True)
    catagory=models.CharField(max_length=500, null=True)
    publisher=models.ForeignKey(Publisher, on_delete= models.PROTECT,null=True)
    pdf=models.FileField(null=True)
    image=models.ImageField(null=True)
    
    
    
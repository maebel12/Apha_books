from django.contrib import admin

# Register your models here.
from .models import Author, Book, Publisher, FileType, Typecatagory
# Register your models here.
admin.site.register(Author)
admin.site.register(Publisher)
admin.site.register(Book)
admin.site.register(FileType)



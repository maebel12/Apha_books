from django.apps import AppConfig


class PublisherDashboardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'publisher_dashboard'

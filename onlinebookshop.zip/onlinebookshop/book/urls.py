from django.urls import path
from .views import Booklistview

urlpatterns = [
    path('booklist', Booklistview.as_view(), ),
]
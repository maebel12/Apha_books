from django.shortcuts import render
from rest_framework import generics
from .models import Book
from .serializers import BookSerialazer
from rest_framework.decorators import api_view, permission_classes
from rest_framework.views import APIView 


class Booklistview(generics.ListAPIView):
    
    queryset= Book.objects.all()
    serializer_Class = BookSerialazer

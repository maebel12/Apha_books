from rest_framework import serializers
from .models import Book
from django.http import JsonResponse


class BookSerialazer(serializers.ModelSerializer):
    class Meta:
        model = Book
        fields= ('name', 'integer')
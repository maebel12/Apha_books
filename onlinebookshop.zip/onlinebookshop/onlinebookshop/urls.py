
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('book/', include('book.urls')),
    path('publisher_dashboard', include('publisher_dashboard.urls')),
    path('user_account', include('user_account.urls')),

]

import 'package:authetrail/contacts.dart';
import 'package:authetrail/publisherdashmain.dart';
import 'package:authetrail/publisherscreen.dart';
import 'package:flutter/material.dart';
import 'accountscreen.dart';
import 'package:authetrail/books.dart';
import 'package:authetrail/magazines.dart';
import 'package:authetrail/newspaper.dart';
import 'package:authetrail/homescreen.dart';
import 'about.dart';

class publisherupload extends StatelessWidget {
  const publisherupload({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     appBar: AppBar(title: Text('publisher/upload file'),),
    drawer: Drawer(
        
        child: ListView(
          children: [
            DrawerHeader(child: Image(image: AssetImage("images/lion.png",),),),
            ListTile(
               title: Text('HOME'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => homescreen(),)
                );
               },
            ),
              ListTile(
               title: Text('BOOKS'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => bookspage(),)
                );
               },
            ),
            ListTile(
               title: Text('MAGAZINE'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => magazinepage(),)
                );
               },
            ),
            ListTile(
               title: Text('NEWSPAPER'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => newspaperpage(),)
                );
               },
            ),
            ListTile(
               title: Text('CHATBOT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => contactpage(),)
                );
               },
            ),
            ListTile(
               title: Text('PUBLISHER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>
                publisherpage(),
                ));
               },
            ),
            ListTile(
               title: Text('MY FILES'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => accountpage(),)
                );
               },
            ),
             ListTile(
               title: Text('ABOUT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => aboutpage(),)
                  );
               },
            ),
          ],
        ),
      ),
      body: Container(
     child: SingleChildScrollView(
        
        child: Column(
                children: [
                    SizedBox(height: 40,),
                  
                TextField(
                  decoration: InputDecoration(
        
                   labelText: 'Title' ,
                    labelStyle: TextStyle(color: Colors.black),
                filled: true,
               floatingLabelBehavior: FloatingLabelBehavior.never,
                   fillColor: Colors.white,
                  border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(width: 0, style: BorderStyle.none)
),),
                ),
                SizedBox(height: 30,),
                TextField(
                  decoration: InputDecoration(
        
                   labelText: 'Authors' ,
                    labelStyle: TextStyle(color: Colors.black),
                filled: true,
               floatingLabelBehavior: FloatingLabelBehavior.never,
                   fillColor: Colors.white,
                  border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(width: 0, style: BorderStyle.none)
),),
                ),
                SizedBox(height: 30,),
                TextField(
                  decoration: InputDecoration(
                     
                   labelText: 'Set price' ,
                    labelStyle: TextStyle(color: Colors.black),
                filled: true,
               floatingLabelBehavior: FloatingLabelBehavior.never,
                   fillColor: Colors.white,
                  border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(width: 0, style: BorderStyle.none)
),),
                ),
                SizedBox(height: 30,),
                Row(
                  children: [
                  Text('file type'),
                SizedBox(width: 20,),
                DropdownButton(
                  
                  items: const[
                    DropdownMenuItem(child: Text('book'), value: 'book',),
                    DropdownMenuItem(child: Text('magazine'), value: 'magazine',),
                    DropdownMenuItem(child: Text('newspaper'), value: 'newspaper',),

                  ],
                   onChanged: null),
                  ],
                 ),
                  TextField(
                  decoration: InputDecoration(
                     
                   labelText: 'catagory' ,
                    labelStyle: TextStyle(color: Colors.black),
                filled: true,
               floatingLabelBehavior: FloatingLabelBehavior.never,
                   fillColor: Colors.white,
                  border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(width: 0, style: BorderStyle.none)
               ),),
                ),
                
                  SizedBox(height: 30,),
                  TextField(
                  decoration: InputDecoration(
                     
                   labelText: 'publisher' ,
                    labelStyle: TextStyle(color: Colors.black),
                filled: true,
               floatingLabelBehavior: FloatingLabelBehavior.never,
                   fillColor: Colors.white,
                  border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(width: 0, style: BorderStyle.none)
               ),),
                ),
                SizedBox(height: 20,),
                Row(
                  children: [
                    SizedBox(height: 30,width: 130,),
                   ElevatedButton(onPressed: (){}, child: Text('upload file')),
                   SizedBox(width: 20,),
                   ElevatedButton(onPressed: (){}, child: Text('upload picture')),
                  ],

                  
                ),


                   SizedBox(height: 30,),
                   ElevatedButton(onPressed: (){}, child: Text('publish'))
                ],
        ),
      ),
    ),
    floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.of(context).push(MaterialPageRoute(builder: (context)=> publishedfiles()));
        },
        child: Icon(Icons.upload),
        
       
      ),
     
    );
  }
}
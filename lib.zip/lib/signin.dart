import 'publisherdash.dart';
import 'package:flutter/material.dart';
import 'package:authetrail/reusable.dart';

import 'about.dart';
import 'package:authetrail/books.dart';
import 'package:authetrail/contacts.dart';
import 'package:authetrail/magazines.dart';
import 'accountscreen.dart';
import 'package:authetrail/newspaper.dart';
import 'package:authetrail/publisherscreen.dart';
import 'package:authetrail/homescreen.dart';

class signInScreen extends StatefulWidget {
  signInScreen({super.key});

  @override
  State<signInScreen> createState() => _signInScreenState();
}

class _signInScreenState extends State<signInScreen> {
        TextEditingController _passwordTextController = TextEditingController();

        TextEditingController _emailTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 0, 0, 0),
      appBar: AppBar(title: Text('PUBLISHER SIGNIN'),
      backgroundColor: Colors.black,
      ),
      drawer: Drawer(
        
        child: ListView(
          children: [
            DrawerHeader(child: Image(image: AssetImage("images/lion.png",),),),
            ListTile(
               title: Text('HOME'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => homescreen(),)
                );
               }, 
            ),
              ListTile(
               title: Text('BOOKS'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => bookspage(),)
                );
               },
            ),
            ListTile(
               title: Text('MAGAZINE'),
               onTap: (){
               Navigator.of(context).push(MaterialPageRoute(builder: (context) => magazinepage(),
               )
               );

               },
            ),
            ListTile(
               title: Text('NEWSPAPER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => newspaperpage(),))
             ;

               },
            ),
            ListTile(
               title: Text('CHATBOT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => contactpage(),)
                );
               },
            ),
            ListTile(
               title: Text('PUBLISHER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>
                publisherpage(),
                ));
               },
            ),
            ListTile(
               title: Text('MY FILES'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => accountpage(),)
                );
               },
            ),
            ListTile(
               title: Text('ABOUT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => aboutpage(),)
                  );
               },
            ),
                
          ],
        ),
      ),
      
      body: Container(
         
        child: SingleChildScrollView(
           
          child: Padding(padding: EdgeInsetsDirectional.fromSTEB(
            20,MediaQuery.of(context).size.height * 0.2,20,0 ),
            child: Column(
              
              children: [
               Text('Welcome to Alpha'),
               SizedBox(height: 20,),
               Image(image: AssetImage("images/lion.png")),
                SizedBox(height: 20,),
               Text('Signin'),
                SizedBox(height: 20,),
                reusable('enter username', Icons.person_outline, false, _emailTextController),
                SizedBox(height: 20,),
                 reusable('enter password', Icons.lock, true, _passwordTextController),
                 SizedBox(height: 20),
                 
                 SizedBox(height: 20),
                 
                  signinsignupButton(
                    context, false, (){
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) =>
                        publisherdash()
                        )
                      );
                    }
                    )
              ],
            ),
            
            
            ),
       
       
       
        ),
      ),
      
      );
  }

}
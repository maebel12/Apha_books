   import 'package:flutter/material.dart';
import 'package:authetrail/signin.dart';

class publisherpage extends StatelessWidget {
  const publisherpage({super.key});

  @override
  Widget build(BuildContext context) {
    return signInScreen();
  }
}
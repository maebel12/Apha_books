import 'package:authetrail/about.dart';
import 'package:authetrail/publisherscreen.dart';
import 'package:authetrail/magazines.dart';
import 'package:authetrail/newspaper.dart';
import 'package:authetrail/searchpage.dart';
import 'package:flutter/material.dart';
import 'accountscreen.dart';
import 'package:authetrail/homescreen.dart';



class bookspage extends StatelessWidget {
  const bookspage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('BOOKS'),
      backgroundColor: Colors.black,
      ),
      drawer: Drawer(
        
        child: ListView(
          children: [
            DrawerHeader(child: Image(image: AssetImage("images/lion.png",),),),
            ListTile(
               title: Text('HOME'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => homescreen(),)
                );
               }, 
            ),
              ListTile(
               title: Text('BOOKS'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => bookspage(),)
                );
               },
            ),
            ListTile(
               title: Text('MAGAZINE'),
               onTap: (){
               Navigator.of(context).push(MaterialPageRoute(builder: (context) => magazinepage(),
               )
               );

               },
            ),
            ListTile(
               title: Text('NEWSPAPER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => newspaperpage(),))
             ;

               },
            ),
            ListTile(
               title: Text('CHATBOT'),
               onTap: (){
                
               },
            ),
            ListTile(
               title: Text('PUBLISHER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>
                publisherpage(),
                ));
               },
            ),
            ListTile(
               title: Text('MY FILES'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => accountpage(),)
                );
               },
            ),
            ListTile(
               title: Text('ABOUT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => aboutpage(),)
                );
               },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.of(context).push(MaterialPageRoute(builder: (context)=> searchpage()));
        },
        child: Icon(Icons.search),
       
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(children: [

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    Text('self help'),
                
              Image(image: AssetImage("images/sec.png",  ),height: 200,
              width: 100,
              ),
               SizedBox(height: 30,),
                  ],
                ),
                
              Image(image: AssetImage("images/gre.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              Image(image: AssetImage("images/best.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              Image(image: AssetImage("images/deep.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              ],
            ),
           SizedBox(height: 30,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,

              children: [
                
              Image(image: AssetImage("images/majic.png",  ),height: 200,
              width: 100,
              ),
               SizedBox(height: 30,),
              Image(image: AssetImage("images/you.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              Image(image: AssetImage("images/design.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              Image(image: AssetImage("images/deep.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                
              Image(image: AssetImage("images/sec.png",  ),height: 200,
              width: 100,
              ),
               SizedBox(height: 30,),
              Image(image: AssetImage("images/gre.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              Image(image: AssetImage("images/self.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              Image(image: AssetImage("images/deep.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                
              Image(image: AssetImage("images/sec.png",  ),height: 200,
              width: 100,
              ),
               SizedBox(height: 30,),
              Image(image: AssetImage("images/gre.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              Image(image: AssetImage("images/best.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              Image(image: AssetImage("images/majic.png"),height: 200,
              width: 100,),
              SizedBox(height: 30,),
              ],
            ),
            
             
           
            
              
            
      
      
            
        
            
          ]),
         
        ),
      ) ,
     
      
    );
  }
}

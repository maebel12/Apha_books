import 'package:flutter/material.dart';
import 'package:authetrail/books.dart';
import 'package:authetrail/contacts.dart';
import 'package:authetrail/magazines.dart';
import 'accountscreen.dart';
import 'package:authetrail/newspaper.dart';
import 'package:authetrail/publisherscreen.dart';
import 'about.dart';
import 'homescreen.dart';
class searchpage extends StatelessWidget {
  const searchpage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('ALPHA'),
      backgroundColor: Colors.black,
      ),

      drawer: Drawer(
        
        child: ListView(
          children: [
            DrawerHeader(child: Image(image: AssetImage("images/lion.png",),),),
            ListTile(
               title: Text('HOME'),
               onTap: (){
                  Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => homescreen(),)
                );
               },
            ),
              ListTile(
               title: Text('BOOKS'),
               onTap: (){
               Navigator.of(context).push(MaterialPageRoute(builder: (context) => bookspage(),
               )        )    ;   },
            ),
            ListTile(
               title: Text('MAGAZINE'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => magazinepage(),));
               },
            ),
            ListTile(
               title: Text('NEWSPAPER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => newspaperpage(),))
             ;

               },
            ),
            ListTile(
               title: Text('CHATBOT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => contactpage(),)
                );
               },
            ),
            ListTile(
               title: Text('PUBLISHER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>
                publisherpage(),
                ));
               },
            ),
            ListTile(
               title: Text('MY FILES'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => accountpage(),)
                );
               },
            ),
             ListTile(
               title: Text('ABOUT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => aboutpage(),)
                  );
               },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.of(context).push(MaterialPageRoute(builder: (context)=> searchpage()));
        },
        child: Icon(Icons.search),
       
      ),
     body: SingleChildScrollView(
          child: Column(
            
            children: [
              SizedBox(height: 5,),

              TextField(
              
        style: TextStyle(color: Colors.black),
        decoration: InputDecoration(
        labelText: 'search',
      
        labelStyle: TextStyle(color: Colors.black),
        filled: true,
        floatingLabelBehavior: FloatingLabelBehavior.never,
        fillColor: Color.fromARGB(255, 3, 195, 205),
        border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide(width: 0, style: BorderStyle.none)
         ),),
              ),
           SizedBox(height: 5,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
              
                ElevatedButton(onPressed: (){}, child: Text('search'),  )
              ],
            ),
           
            ]),
         
        ),
     
     
      );
      



  
  }
}
import 'package:authetrail/searchpage.dart';
import 'package:flutter/material.dart';
import 'package:authetrail/books.dart';
import 'package:authetrail/contacts.dart';
import 'package:authetrail/magazines.dart';
import 'accountscreen.dart';
import 'package:authetrail/newspaper.dart';
import 'package:authetrail/publisherscreen.dart';
import 'package:authetrail/homescreen.dart';

class aboutpage extends StatelessWidget {
  const aboutpage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:  Colors.black,
      appBar: AppBar(title: Text('ABOUT'),
      backgroundColor: Colors.black,
      ),
      drawer: Drawer(
        
        child: ListView(
          children: [
            DrawerHeader(child: Image(image: AssetImage("images/lion.png",),),),
            ListTile(
               title: Text('HOME'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => homescreen(),)
                );
               }, 
            ),
              ListTile(
               title: Text('BOOKS'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => bookspage(),)
                );
               },
            ),
            ListTile(
               title: Text('MAGAZINE'),
               onTap: (){
               Navigator.of(context).push(MaterialPageRoute(builder: (context) => magazinepage(),
               )
               );

               },
            ),
            ListTile(
               title: Text('NEWSPAPER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => newspaperpage(),))
             ;

               },
            ),
            ListTile(
               title: Text('CHATBOT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => contactpage(),)
                );
               },
            ),
            ListTile(
               title: Text('PUBLISHER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>
                publisherpage(),
                ));
               },
            ),
            ListTile(
               title: Text('MY FILES'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => accountpage(),)
                );
               },
            ),
            ListTile(
               title: Text('ABOUT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => aboutpage(),)
                  );
               },
            ),
                
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (context)=> searchpage()));
        },
        child: Icon(Icons.search),
       
      ),
    
    body: SingleChildScrollView(
      child: Center(
        child: Column(
          children: [
            SizedBox(height: 20,),
             Image(image: AssetImage("images/lion.png")),
            SizedBox(height: 20,),
            Text('About'),
            SizedBox(height: 20,),
            Text('Alpha book is a digital publishing company for books, magazines, and newspaper that allows publishers and authors to publish, track sells, and communicate with readers.', style: Theme.of(context).textTheme.bodyText2,),
            SizedBox(height: 20,),
            Text('Our mission'),
            SizedBox(height: 20,),
            Text('Our mission is to inspire, educate, entertain, and enlighten readers by publishing high-quality content that captivates, informs, and sparks meaningful conversations. We aim to promote diverse voices, foster creativity, and contribute to the cultural and intellectual enrichment of society. Through innovative approaches and partnerships, we strive to connect authors with their audience, embrace emerging technologies, and adapt to the ever-evolving landscape of the publishing industry.', style: Theme.of(context).textTheme.bodyText2,),
            SizedBox(height: 20,),
            Text('Our core values'),
            SizedBox(height: 20,),

            Text('1. Quality: Striving for excellence in content creation, editing, and design.', style: Theme.of(context).textTheme.bodyText2,), 
            SizedBox(height: 20,),
            Text('2. Integrity: Maintaining honesty, transparency, and ethical practices in all publishing operations.', style: Theme.of(context).textTheme.bodyText2,),
             SizedBox(height: 20,),
            Text('3. Creativity: Encouraging and fostering innovation, originality, and artistic expression in publishing endeavors.', style: Theme.of(context).textTheme.bodyText2,) ,
             SizedBox(height: 20,),
            Text('4. Diversity: Embracing and promoting inclusivity, representing diverse voices, experiences, and perspectives.', style: Theme.of(context).textTheme.bodyText2,) ,
             SizedBox(height: 20,),
            Text('5. Collaboration: Valuing teamwork, partnerships, and cooperation with authors, editors, and other publishing professionals.', style: Theme.of(context).textTheme.bodyText2,) ,
             SizedBox(height: 20,),
            Text('6. Accessibility: Making published works available and affordable to a wide range of readers.', style: Theme.of(context).textTheme.bodyText2,) ,
             SizedBox(height: 20,),
            Text('7. Responsiveness: Adapting to emerging technologies and changing market trends to meet readers', style: Theme.of(context).textTheme.bodyText2,) ,
             SizedBox(height: 20,),
            Text('8. Respect: Treating all individuals, be it employees, authors, or readers, with dignity, fairness, and respect.', style: Theme.of(context).textTheme.bodyText2,) ,
             SizedBox(height: 20,),
            Text('9. Environmental Responsibility: Implementing sustainable practices to minimize the ecological impact of publishing activities.', style: Theme.of(context).textTheme.bodyText2,) ,
             SizedBox(height: 20,),
            Text('10. Passion for Literature: Fostering a deep love for books, knowledge, and the power of storytelling.', style: Theme.of(context).textTheme.bodyText2,) 

          ],
        ),
      ),
    ),
    
    );
  }
}
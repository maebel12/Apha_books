import 'package:authetrail/homescreen.dart';

import 'package:flutter/material.dart';
import 'package:authetrail/reusable.dart';
class signupscreen extends StatefulWidget {
  const signupscreen({super.key});

  @override
  State<signupscreen> createState() => _signupscreenState();
}

class _signupscreenState extends State<signupscreen> {
        TextEditingController _passwordTextController = TextEditingController();

        TextEditingController _emailTextController = TextEditingController();
  TextEditingController _userNameTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'signup'
        ),
        ),
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: SingleChildScrollView(
            
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(
            20,MediaQuery.of(context).size.height * 0.2,20,0 ),
              child: Column(
                children: <Widget>[
                  SizedBox(height: 20,),
                  reusable('enter username', Icons.person_outline, false, _userNameTextController),
                  SizedBox(height: 20,),
                  reusable('enter email', Icons.person_outline, false, _emailTextController),
                  SizedBox(height: 20,),
                  reusable('enter password', Icons.person_outline, false, _passwordTextController),
                  SizedBox(height: 20,),
                  signinsignupButton(
                    context, false, (){
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) =>
                        homescreen()
                        )
                      );
                    }
                    )
                ],
              ),
            ),
          ),
        ),
    );
  }
}
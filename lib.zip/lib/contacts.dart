
import 'package:authetrail/searchpage.dart';
import 'package:flutter/material.dart';
import 'package:authetrail/books.dart';
import 'package:authetrail/publisherscreen.dart';
import 'package:authetrail/magazines.dart';
import 'package:authetrail/newspaper.dart';
import 'about.dart';
import 'accountscreen.dart';
import 'package:authetrail/homescreen.dart';


class contactpage extends StatefulWidget {
  const contactpage({super.key});

  @override
  State<contactpage> createState() => _contactpageState();
}

class _contactpageState extends State<contactpage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('CHATBOT'),
      backgroundColor: Colors.black,
      ),
      drawer: Drawer(
        
        child: ListView(
          children: [
            DrawerHeader(child: Image(image: AssetImage("images/lion.png",),),),
            ListTile(
               title: Text('HOME'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => homescreen(),)
                );
               }, 
            ),
              ListTile(
               title: Text('BOOKS'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => bookspage(),)
                );
               },
            ),
            ListTile(
               title: Text('MAGAZINE'),
               onTap: (){
               Navigator.of(context).push(MaterialPageRoute(builder: (context) => magazinepage(),
               )
               );

               },
            ),
            ListTile(
               title: Text('NEWSPAPER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => newspaperpage(),))
             ;

               },
            ),
            ListTile(
               title: Text('CHATBOT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => contactpage(),)
                );
               },
            ),
            ListTile(
               title: Text('PUBLISHER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>
                publisherpage(),
                ));
               },
            ),
            ListTile(
               title: Text('MY FILES'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => accountpage(),)
                );
               },
            ),
             ListTile(
               title: Text('ABOUT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => aboutpage(),)
                  );
               },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (context)=> searchpage()));
        },
        child: Icon(Icons.search),
       
      ),
   
     bottomNavigationBar:  BottomNavigationBar(
     
          items:[
       BottomNavigationBarItem(
        
        icon: Icon(Icons.message,), 
        label: 'message',
        
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.person,), 
        label: 'contacts',
        
      ),
      
      
      ] 
       
     ),
    );
  
  }
}
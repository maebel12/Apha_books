import 'package:authetrail/homescreen.dart';
import 'package:authetrail/signup.dart';

import 'publisherdash.dart';
import 'package:flutter/material.dart';
import 'package:authetrail/reusable.dart';



class Usersignin extends StatefulWidget {
  const Usersignin({super.key});

  @override
  State<Usersignin> createState() => _UsersigninState();
}

class _UsersigninState extends State<Usersignin> {
     TextEditingController _passwordTextController = TextEditingController();

     TextEditingController _emailTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      backgroundColor: Color.fromARGB(255, 0, 0, 0),
      appBar: AppBar(title: Text('PUBLISHER SIGNIN'),
      backgroundColor: Colors.black,
      ),
      body: Container(
         
        child: SingleChildScrollView(
           
          child: Padding(padding: EdgeInsetsDirectional.fromSTEB(
            20,MediaQuery.of(context).size.height * 0.2,20,0 ),
            child: Column(
              
              children: [
               Text('Welcome to Alpha'),
               SizedBox(height: 20,),
               Image(image: AssetImage("images/lion.png")),
                SizedBox(height: 20,),
               Text('Signin'),
                SizedBox(height: 20,),
                reusable('enter username', Icons.person_outline, false, _emailTextController),
                SizedBox(height: 20,),
                 reusable('enter password', Icons.lock, true, _passwordTextController),
                 SizedBox(height: 20),
                 
                 SizedBox(height: 20),
                 
                  signinsignupButton(
                    context, false, (){
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) =>
                        homescreen()
                        )
                      );
                    }
                    ),
                    SizedBox(height: 20,),
                    Text('create account'),
                    SizedBox(height: 20,),
                    ElevatedButton(onPressed: (){
                      Navigator.of(context).push(MaterialPageRoute(builder: (context)=> signupscreen()));
                    }, child: Text('SIGNUP'))
                
              ],
            ),
            
            
            ),
       
       
       
        ),
      ),
      
      
    );
  }
}
import 'package:authetrail/contacts.dart';
import 'package:authetrail/publisherscreen.dart';
import 'package:authetrail/publisherupload.dart';
import 'package:flutter/material.dart';
import 'accountscreen.dart';
 import 'package:authetrail/publisherdashmain.dart';
import 'package:authetrail/books.dart';
import 'package:authetrail/magazines.dart';
 import 'package:authetrail/newspaper.dart';
 import 'package:authetrail/homescreen.dart';
 import 'about.dart';
class publisherdash extends StatelessWidget {
  const publisherdash({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('PUBLISHER dashboard'),),
      drawer: Drawer(
        
        child: ListView(
          children: [
            DrawerHeader(child: Image(image: AssetImage("images/lion.png",),),),
            ListTile(
               title: Text('HOME'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => homescreen(),)
                );
               },
            ),
              ListTile(
               title: Text('BOOKS'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => bookspage(),)
                );
               },
            ),
            ListTile(
               title: Text('MAGAZINE'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => magazinepage(),)
                );
               },
            ),
            ListTile(
               title: Text('NEWSPAPER'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => newspaperpage(),)
                );
               },
            ),
            ListTile(
               title: Text('CHATBOT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => contactpage(),)
                );
               },
            ),
            ListTile(
               title: Text('PUBLISHER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>
                publisherpage(),
                ));
               },
            ),
            ListTile(
               title: Text('MY FILES'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => accountpage(),)
                );
               },
            ),
             ListTile(
               title: Text('ABOUT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => aboutpage(),)
                  );
               },
            ),
          ],
        ),
      ),
      body: Center(
        child: Column( children: [
            SizedBox(height: 200, width: 150,),
          ElevatedButton(onPressed: (){
             Navigator.of(context).push(MaterialPageRoute(builder: (context) => publisherupload()));
          }, child: Text('upload file'),
          style: ButtonStyle(
  backgroundColor: MaterialStateProperty.resolveWith((states) {
    if(states.contains(MaterialState.pressed)){
      return Colors.black26;
    }
    return Color.fromARGB(255, 71, 243, 3);
  }),
  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
  RoundedRectangleBorder(borderRadius: BorderRadius.circular(30))
  ),
),
          ),
          SizedBox(height:20,width: 50 ),
          ElevatedButton(onPressed: (){
             Navigator.of(context).push(MaterialPageRoute(builder: (context) => publishedfiles()));
          }, child: Text('published file'),
          style: ButtonStyle(
  backgroundColor: MaterialStateProperty.resolveWith((states) {
    if(states.contains(MaterialState.pressed)){
      return Colors.black26;
    }
    return Color.fromARGB(255, 71, 243, 3);
  }),
  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
  RoundedRectangleBorder(borderRadius: BorderRadius.circular(30))
  ),
),
          )
          ],
          ),

     ),
    );
  }
}
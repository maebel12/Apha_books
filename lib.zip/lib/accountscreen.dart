
import 'package:authetrail/contacts.dart';
import 'package:authetrail/homescreen.dart';
import 'package:authetrail/searchpage.dart';
import 'package:flutter/material.dart';
import 'package:authetrail/books.dart';
import 'package:authetrail/magazines.dart';
import 'package:authetrail/newspaper.dart';
import 'package:authetrail/publisherscreen.dart';
import 'about.dart';
class accountpage extends StatelessWidget {
  const accountpage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('downloaded file'),),
     drawer: Drawer(
        
        child: ListView(
          children: [
            DrawerHeader(child: Image(image: AssetImage("images/lion.png",),),),
            ListTile(
               title: Text('HOME'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => homescreen(),)
                );
               },
            ),
              ListTile(
               title: Text('BOOKS'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => bookspage(),)
                );
               },
            ),
            ListTile(
               title: Text('MAGAZINE'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => magazinepage(),)
                );
               },
            ),
            ListTile(
               title: Text('NEWSPAPER'),
               onTap: (){
                 Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => newspaperpage(),)
                );
               },
            ),
            ListTile(
               title: Text('CHATBOT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => contactpage(),)
                );
               },
            ),
            ListTile(
               title: Text('PUBLISHER'),
               onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>
                publisherpage(),
                ));
               },
            ),
            ListTile(
               title: Text('MY FILES'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => accountpage(),)
                );
               },
            ),
             ListTile(
               title: Text('ABOUT'),
               onTap: (){
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => aboutpage(),)
                  );
               },
            ),
          ],
        ),
      ),
     floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.of(context).push(MaterialPageRoute(builder: (context)=> searchpage()));
        },
        child: Icon(Icons.search),
       
      ),
    body: Container(

    ),
    
      );
  }
}